(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// CoderClicker.js                                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
                                                                       //
  Accounts.ui.config({                                                 // 3
    passwordSignupFields: 'USERNAME_ONLY'                              // 4
  });                                                                  //
                                                                       //
  Meteor.subscribe('userData');                                        // 7
                                                                       //
  Template.hello.user = function () {                                  // 9
    return Meteor.user();                                              // 10
  };                                                                   //
                                                                       //
  Template.hello.items = function () {                                 // 13
    return [{ name: "Buy Online Courses", cost: 1000, icon: "graduation-cap", kw: "courses", dps: 2 }, { name: "Hire Junior Programmer", cost: 2000, icon: "user-plus", kw: "jprog", dps: 4 }, { name: "Hire Marketing Professional", cost: 4000, icon: "shopping-cart", kw: "market", dps: 8 }, { name: "Hire Lawyer", cost: 8000, icon: "legal", kw: "law", dps: 16 }, { name: "Hire Team", cost: 25000, icon: "group", kw: "team", dps: 50 }, { name: "your product", cost: 30000, icon: "trademark", kw: "tm", dps: 60 }, { name: "Invest in ads", cost: 60000, icon: "tv", kw: "ad", dps: 120 }, { name: "Rent an incubator", cost: 100000, icon: "home", kw: "inc", dps: 200 }, { name: "Create Reliable Servers", cost: 300000, icon: "server", kw: "serv", dps: 600 }, { name: "Buy HQ", cost: 1000000, icon: "institution", kw: "hq", dps: 2000 }, { name: "Buy Company", cost: 5000000, icon: "money", kw: "comp", dps: 10000 }];
  };                                                                   //
                                                                       //
  Template.hello.events({                                              // 27
    'click button.code': function () {                                 // 28
      Meteor.call('click');                                            // 29
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.hello.events({                                              // 34
    'click button.buy': function (event) {                             // 35
      Meteor.call('buy', event.target.id, event.target.name);          // 36
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.hello.events({                                              // 40
    'click #ldb': function (event) {                                   // 41
      $("table").toggle();                                             // 42
      return false;                                                    // 43
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.hello.players = function () {                               // 47
    return Meteor.users.find({}, { sort: { 'money': -1 } });           // 48
  };                                                                   //
                                                                       //
  UI.registerHelper('formatCurrency', function (context, options) {    // 51
    return numeral(context).format('0,0');                             // 52
  });                                                                  //
                                                                       //
  Template.login.events({                                              // 55
    'click #facebook-login': function (event) {                        // 56
      Meteor.loginWithFacebook({}, function (err) {                    // 57
        if (err) {                                                     // 58
          throw new Meteor.Error("Facebook login failed");             // 59
        }                                                              //
      });                                                              //
    },                                                                 //
                                                                       //
    'click #logout': function (event) {                                // 64
      Meteor.logout(function (err) {                                   // 65
        if (err) {                                                     // 66
          throw new Meteor.Error("Logout failed");                     // 67
        }                                                              //
      });                                                              //
    }                                                                  //
  });                                                                  //
                                                                       //
  Meteor.startup(function () {                                         // 73
    $('html').bind('keypress', function (e) {                          // 74
      if (e.keyCode == 13 || e.keyCode == 32) {                        // 75
        return false;                                                  // 76
      }                                                                //
    });                                                                //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 81
                                                                       //
  Meteor.startup(function () {                                         // 83
    Meteor.setInterval(function () {                                   // 84
      Meteor.users.find({}).map(function (user) {                      // 85
        Meteor.users.update({ _id: user._id }, { $inc: { 'money': user.rate } });
      });                                                              //
    }, 1000);                                                          //
  });                                                                  //
                                                                       //
  Accounts.onCreateUser(function (options, user) {                     // 91
    user.money = 0;                                                    // 92
    user.rate = 0;                                                     // 93
    user.lines = 0;                                                    // 94
    user.jprog = 0;                                                    // 95
    user.courses = 0;                                                  // 96
    user.market = 0;                                                   // 97
    user.law = 0;                                                      // 98
    user.team = 0;                                                     // 99
    user.tm = 0;                                                       // 100
    user.ad = 0;                                                       // 101
    user.inc = 0;                                                      // 102
    user.serv = 0;                                                     // 103
    user.hq = 0;                                                       // 104
    user.comp = 0;                                                     // 105
    return user;                                                       // 106
  });                                                                  //
                                                                       //
  Meteor.publish("userData", function () {                             // 109
    return Meteor.users.find({}, { sort: { 'money': -1 } });           // 110
  });                                                                  //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 114
  click: function () {                                                 // 115
    Meteor.users.update({ _id: this.userId }, { $inc: { 'money': 50, 'lines': 1 } });
    var btn = $('.code');                                              // 117
    btn.prop('disabled', true);                                        // 118
    window.setTimeout(function () {                                    // 119
      btn.prop('disabled', false);                                     // 120
    }, 150);                                                           //
  },                                                                   //
  buy: function (amount, qty) {                                        // 123
    if (Meteor.user().money >= amount && amount > 0) {                 // 124
      Meteor.users.update({ _id: this.userId }, { $inc: { 'rate': Math.floor(amount / 500), 'money': 0 - amount } });
      var q = qty,                                                     // 126
          doc = {};                                                    //
      doc[q] = 1;                                                      // 127
      Meteor.users.update({ _id: this.userId }, { $inc: doc });        // 128
      var btn = $('.buy');                                             // 129
      btn.prop('disabled', true);                                      // 130
      window.setTimeout(function () {                                  // 131
        btn.prop('disabled', false);                                   // 132
      }, 100);                                                         //
    }                                                                  //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=CoderClicker.js.map
