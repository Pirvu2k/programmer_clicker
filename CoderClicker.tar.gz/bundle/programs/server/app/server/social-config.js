(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/social-config.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
ServiceConfiguration.configurations.remove({                           // 1
    service: 'facebook'                                                // 2
});                                                                    //
                                                                       //
ServiceConfiguration.configurations.insert({                           // 5
    service: 'facebook',                                               // 6
    appId: '1035959779784039',                                         // 7
    secret: '0fcbbfbdb75d8cb20175c1f7783077e4'                         // 8
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=social-config.js.map
